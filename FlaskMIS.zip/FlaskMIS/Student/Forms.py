from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, BooleanField
from wtforms.validators import DataRequired, Length, EqualTo, ValidationError
from FlaskMIS.models import Students

class RegistrationForm(FlaskForm):
    name = StringField('Full Name', validators=[DataRequired()])
    username = StringField('Username', validators= [DataRequired(), Length(min=2, max=20)])
    password = PasswordField('Password', validators= [DataRequired(), Length(min=2, max=15)])
    confirm_password = PasswordField('Confirm Password', validators=[DataRequired(), EqualTo('password')])

    submit = SubmitField('Sign Up')

    def validate_username(self, username):
        student = Students.query.filter_by(username = username.data).first()
        if student:
            raise ValidationError("Username is already taken. Please choose a different one.")

class LoginForm(FlaskForm):
    username = StringField('Username', validators= [DataRequired(), Length(min=2, max=20)])
    password = PasswordField('Password', validators= [DataRequired(), Length(min=2, max=15)])
    remember = BooleanField('Remember Me')
    
    submit = SubmitField('Login')